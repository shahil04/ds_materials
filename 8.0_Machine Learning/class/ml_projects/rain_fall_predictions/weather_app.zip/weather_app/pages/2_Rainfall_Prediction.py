import streamlit as st
import pandas as pd
import pickle
from pathlib import Path

st.title("🌧 AI Rainfall Prediction")

model_path = Path("rainfall_prediction_model.pkl")
if not model_path.exists():
    st.warning("Model file not found. Using placeholder dummy model.")
    best_rf_model = None
else:
    with open(model_path, "rb") as f:
        model_obj = pickle.load(f)
        best_rf_model = model_obj.get("model", None)

st.markdown("<div class='card'><h3>Enter Weather Details</h3></div>", unsafe_allow_html=True)

col1, col2, col3 = st.columns(3)

pressure = col1.number_input("Pressure (hPa)", value=1015.0)
dewpoint = col2.number_input("Dew Point (°C)", value=20.0)
humidity = col3.number_input("Humidity (%)", value=60)

cloud = col1.number_input("Cloud (%)", value=40)
sunshine = col2.number_input("Sunshine (hours)", value=6)
winddirection = col3.number_input("Wind Direction (°)", value=180)
windspeed = col1.number_input("Wind Speed (km/h)", value=8.0)

input_df = pd.DataFrame([[pressure, dewpoint, humidity, cloud, sunshine, winddirection, windspeed]],
                        columns=['pressure', 'dewpoint', 'humidity', 'cloud', 'sunshine', 'winddirection', 'windspeed'])

if st.button("Predict"):
    if best_rf_model is None:
        st.error("No model available. Please add your 'rainfall_prediction_model.pkl' to the app folder.")
    else:
        res = best_rf_model.predict(input_df)[0]
        if res == 1:
            st.success("🌧 Rainfall Likely")
        else:
            st.info("☀ No Rainfall Expected")