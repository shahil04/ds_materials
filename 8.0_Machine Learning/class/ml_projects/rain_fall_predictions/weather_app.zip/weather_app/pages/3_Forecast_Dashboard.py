import streamlit as st
import pandas as pd
import requests

API_KEY = "30dc3ec276c49ac523c3cfb2848e0"

def get_lat_lon(city):
    url = f"http://api.openweathermap.org/geo/1.0/direct?q={city}&limit=1&appid={API_KEY}"
    res = requests.get(url).json()
    if not res:
        return None, None
    return res[0]["lat"], res[0]["lon"]

def get_forecast(lat, lon):
    url = f"https://api.openweathermap.org/data/2.5/forecast?lat={lat}&lon={lon}&units=metric&appid={API_KEY}"
    return requests.get(url).json()

st.title("📊 Weather Forecast (5 Days)")

city = st.text_input("Enter city", "Delhi")

if st.button("Show Forecast"):
    lat, lon = get_lat_lon(city)
    if lat is None:
        st.error("City not found.")
    else:
        data = get_forecast(lat, lon)
        df = pd.json_normalize(data["list"])
        df["time"] = df["dt_txt"]
        df.set_index("time", inplace=True)

        st.markdown("<div class='card'><h3>Forecast Trends</h3></div>", unsafe_allow_html=True)
        st.line_chart(df[["main.temp", "main.humidity", "wind.speed"]])

        st.write("### 🔍 Full Forecast Table")
        st.dataframe(df)