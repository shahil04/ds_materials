# Titanic Survival Prediction — Logistic Regression (Complete Project)

**Goal:** Build a production-quality classification project using *Logistic Regression* to predict whether a passenger survived the Titanic disaster.

- **Algorithm:** Logistic Regression (baseline + tuned)
- **Dataset:** Classic Titanic (Kaggle `train.csv` / `test.csv` or any equivalent titanic.csv)
- **Outputs:** Cleaned dataset, fitted model, metrics, plots, and a short model card.

---

## Project Structure

```
titanic-logreg-project/
├── README.md
├── requirements.txt
├── .gitignore
├── data/
│   ├── README_DATA.md
│   ├── train.csv            # Put Kaggle file here (not included)
│   └── test.csv             # Optional (for Kaggle-style split)
├── notebooks/
│   └── titanic_logreg_project.ipynb
├── src/
│   ├── data_prep.py
│   ├── features.py
│   ├── train.py
│   ├── evaluate.py
│   └── cli.py
└── reports/
    ├── figures/             # auto-saved plots
    └── model_card.md
```

## Quickstart

1. **Create environment & install deps**
   ```bash
   pip install -r requirements.txt
   ```

2. **Add data**
   - Download Kaggle Titanic data and place `train.csv` (and optionally `test.csv`) into `data/`.
   - Or place any single `titanic.csv` and edit paths in the notebook/CLI.

3. **Run end-to-end (CLI)**
   ```bash
   # train and evaluate
   python -m src.cli --train_path data/train.csv --out_dir reports
   ```

4. **Open the notebook**
   ```bash
   jupyter notebook notebooks/titanic_logreg_project.ipynb
   ```

---

## Methodology Summary

- **EDA:** class balance, missingness, numeric vs categorical distributions, correlations.
- **Preprocessing:**
  - Impute: `Age` (median), `Embarked` (most frequent), `Fare` (median if missing), drop or simplify `Cabin`.
  - Encode: `Sex`, `Embarked` (one‑hot).
  - Feature engineering: `FamilySize = SibSp + Parch + 1`, `IsAlone`, `Title` from `Name`, optionally bin `Age` and `Fare` for exploration.
  - Scale numeric features with `StandardScaler` (within `Pipeline`).
- **Split:** stratified train/valid (e.g., 80/20).
- **Model:** `LogisticRegression(solver="liblinear" or "lbfgs", class_weight="balanced" optional)`.
- **Tuning:** `GridSearchCV` over `C`, `penalty`, and `class_weight`.
- **Evaluation:** Accuracy, Precision, Recall, F1, ROC AUC, confusion matrix, ROC & PR curves.
- **Interpretation:** coefficients → odds ratios, feature importances by magnitude.
- **Threshold tuning:** choose a probability cutoff optimizing F1 / preferred metric.
- **Reproducibility:** `random_state`, `Pipeline`, pinned deps, saved artifacts.
- **Deliverables:** saved model (`.joblib`), plots in `reports/figures`, and `model_card.md`.

---

## Notes

- This template avoids internet calls. Place your CSVs in `data/`.
- Works on Windows/Mac/Linux and in notebooks/colab with local upload.
- Date generated: 2025-08-29.
