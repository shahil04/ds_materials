from __future__ import annotations
import pandas as pd
from typing import Tuple

EXPECTED_COLUMNS = [
    "Survived","Pclass","Name","Sex","Age","SibSp","Parch","Ticket","Fare","Cabin","Embarked"
]

def load_data(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    return df

def train_valid_split(df: pd.DataFrame, y_col: str = "Survived", test_size: float = 0.2, random_state: int = 42):
    from sklearn.model_selection import train_test_split
    X = df.drop(columns=[y_col])
    y = df[y_col]
    return train_test_split(X, y, test_size=test_size, random_state=random_state, stratify=y)

def add_engineered_features(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    # FamilySize and IsAlone
    if {"SibSp","Parch"}.issubset(out.columns):
        out["FamilySize"] = out["SibSp"].fillna(0) + out["Parch"].fillna(0) + 1
        out["IsAlone"] = (out["FamilySize"] == 1).astype(int)
    # Extract Title from Name
    if "Name" in out.columns:
        out["Title"] = out["Name"].str.extract(r",\s*([^\.]+)\.", expand=False).fillna("Unknown")
        # Map rare titles
        rare = out["Title"].value_counts()[out["Title"].value_counts() < 10].index
        out["Title"] = out["Title"].replace(rare, "Rare")
    return out
