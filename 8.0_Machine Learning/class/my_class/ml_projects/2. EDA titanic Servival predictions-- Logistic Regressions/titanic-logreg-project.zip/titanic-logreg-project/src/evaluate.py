from __future__ import annotations
import os
import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, roc_curve, precision_recall_curve, confusion_matrix, ConfusionMatrixDisplay
)

def save_roc_pr_curves(y_true, y_prob, out_dir="reports/figures"):
    os.makedirs(out_dir, exist_ok=True)
    # ROC
    fpr, tpr, _ = roc_curve(y_true, y_prob)
    plt.figure()
    plt.plot(fpr, tpr, label="ROC")
    plt.plot([0,1],[0,1], linestyle="--")
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC Curve")
    plt.legend()
    roc_path = os.path.join(out_dir, "roc_curve.png")
    plt.savefig(roc_path, bbox_inches="tight")
    plt.close()

    # PR
    precision, recall, _ = precision_recall_curve(y_true, y_prob)
    plt.figure()
    plt.plot(recall, precision, label="PR")
    plt.xlabel("Recall")
    plt.ylabel("Precision")
    plt.title("Precision-Recall Curve")
    plt.legend()
    pr_path = os.path.join(out_dir, "pr_curve.png")
    plt.savefig(pr_path, bbox_inches="tight")
    plt.close()

    return roc_path, pr_path

def threshold_metrics(y_true, y_prob, threshold: float):
    y_pred = (y_prob >= threshold).astype(int)
    return dict(
        accuracy=accuracy_score(y_true, y_pred),
        precision=precision_score(y_true, y_pred),
        recall=recall_score(y_true, y_pred),
        f1=f1_score(y_true, y_pred)
    )

def evaluate_model(model_path: str, X, y, out_dir="reports"):
    os.makedirs(out_dir, exist_ok=True)
    model = joblib.load(model_path)
    y_prob = model.predict_proba(X)[:,1]
    y_pred = (y_prob >= 0.5).astype(int)

    metrics = dict(
        accuracy=accuracy_score(y, y_pred),
        precision=precision_score(y, y_pred),
        recall=recall_score(y, y_pred),
        f1=f1_score(y, y_pred),
        roc_auc=roc_auc_score(y, y_prob),
        confusion_matrix=confusion_matrix(y, y_pred).tolist()
    )

    # Plots
    roc_path, pr_path = save_roc_pr_curves(y, y_prob, out_dir=os.path.join(out_dir,"figures"))

    # Confusion Matrix plot
    plt.figure()
    ConfusionMatrixDisplay.from_predictions(y, y_pred)
    plt.title("Confusion Matrix (threshold=0.5)")
    cm_path = os.path.join(out_dir, "figures", "confusion_matrix.png")
    plt.savefig(cm_path, bbox_inches="tight")
    plt.close()

    # Save metrics
    import json
    with open(os.path.join(out_dir, "metrics.json"), "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2)

    return metrics, {"roc": roc_path, "pr": pr_path, "cm": cm_path}
