from __future__ import annotations
import os, joblib
import pandas as pd
from typing import Tuple
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import classification_report, roc_auc_score
from .data_prep import load_data, train_valid_split, add_engineered_features
from .features import build_preprocessor

RANDOM_STATE = 42

def make_pipeline(feature_names):
    pre, numeric, categorical = build_preprocessor(feature_names)
    clf = LogisticRegression(max_iter=1000, solver="liblinear")
    pipe = Pipeline(steps=[("pre", pre), ("clf", clf)])
    return pipe

def tune_hyperparams(pipe, X_train, y_train):
    param_grid = {
        "clf__C": [0.01, 0.1, 1.0, 10.0],
        "clf__penalty": ["l1", "l2"],
        "clf__class_weight": [None, "balanced"]
    }
    gs = GridSearchCV(pipe, param_grid=param_grid, scoring="f1", cv=5, n_jobs=-1, refit=True, verbose=0)
    gs.fit(X_train, y_train)
    return gs

def train_main(train_path: str, out_dir: str = "reports"):
    os.makedirs(out_dir, exist_ok=True)
    os.makedirs(os.path.join(out_dir, "models"), exist_ok=True)

    df = load_data(train_path)
    df = add_engineered_features(df)

    # Drop columns we won't use directly
    drop_cols = [c for c in ["Cabin","Ticket","Name"] if c in df.columns]
    if drop_cols:
        df = df.drop(columns=drop_cols)

    X_train, X_valid, y_train, y_valid = train_valid_split(df)

    feature_names = X_train.columns.tolist()
    pipe = make_pipeline(feature_names)

    # Tuning
    gs = tune_hyperparams(pipe, X_train, y_train)

    # Evaluate on validation
    y_prob = gs.predict_proba(X_valid)[:,1]
    y_pred = gs.predict(X_valid)
    auc = roc_auc_score(y_valid, y_prob)
    report = classification_report(y_valid, y_pred, digits=4)

    # Save model
    model_path = os.path.join(out_dir, "models", "logreg_titanic.joblib")
    joblib.dump(gs.best_estimator_, model_path)

    # Save text report
    with open(os.path.join(out_dir, "train_report.txt"), "w", encoding="utf-8") as f:
        f.write("Best Params: \n" + str(gs.best_params_) + "\n\n")
        f.write("Validation Classification Report:\n" + report + "\n")
        f.write(f"ROC AUC: {auc:.4f}\n")

    return {
        "best_params": gs.best_params_,
        "auc": auc,
        "model_path": model_path,
        "report_path": os.path.join(out_dir, "train_report.txt")
    }
