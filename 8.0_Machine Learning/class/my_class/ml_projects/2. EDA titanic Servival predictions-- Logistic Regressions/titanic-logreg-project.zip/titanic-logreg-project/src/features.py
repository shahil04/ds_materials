from __future__ import annotations
from typing import List, Tuple
import numpy as np
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer

def build_preprocessor(feature_names: List[str]) -> Tuple[ColumnTransformer, List[str], List[str]]:
    # Define simple type-based splits
    categorical = [c for c in feature_names if c in ["Sex","Embarked","Title"]]
    numeric = [c for c in feature_names if c in ["Age","Fare","Pclass","SibSp","Parch","FamilySize","IsAlone"]]

    num_pipe = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])

    cat_pipe = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("ohe", OneHotEncoder(handle_unknown="ignore", sparse_output=False))
    ])

    pre = ColumnTransformer(
        transformers=[
            ("num", num_pipe, numeric),
            ("cat", cat_pipe, categorical)
        ],
        remainder="drop"
    )
    return pre, numeric, categorical
