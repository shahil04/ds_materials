from __future__ import annotations
import argparse, os
import pandas as pd
from .train import train_main
from .data_prep import load_data, add_engineered_features, train_valid_split
from .evaluate import evaluate_model

def main():
    parser = argparse.ArgumentParser(description="Titanic Logistic Regression — Train & Evaluate")
    parser.add_argument("--train_path", type=str, required=True, help="Path to train CSV (contains Survived)")
    parser.add_argument("--out_dir", type=str, default="reports", help="Output directory")
    args = parser.parse_args()

    # Train
    results = train_main(args.train_path, out_dir=args.out_dir)
    print("Best Params:", results["best_params"])
    print("Model saved:", results["model_path"])
    print("Train report:", results["report_path"])

    # Evaluate on holdout created inside training step
    df = load_data(args.train_path)
    df = add_engineered_features(df)
    # Align with training drops
    drop_cols = [c for c in ["Cabin","Ticket","Name"] if c in df.columns]
    if drop_cols:
        df = df.drop(columns=drop_cols)
    X_train, X_valid, y_train, y_valid = train_valid_split(df)
    metrics, fig_paths = evaluate_model(results["model_path"], X_valid, y_valid, out_dir=args.out_dir)
    print("Validation metrics:", metrics)
    print("Figures:", fig_paths)

if __name__ == "__main__":
    main()
