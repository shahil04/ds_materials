# Model Card — Titanic Logistic Regression

**Date:** 2025-08-29

## Intended Use
Educational binary classifier to predict Titanic survival from passenger metadata.

## Data
Kaggle Titanic (`train.csv`). Class imbalance present (survivors < non-survivors). Missing `Age`, `Cabin`, `Embarked` common.

## Model
Scikit-learn Logistic Regression in a preprocessing `Pipeline` with imputers, one-hot encoders, and scalers.

## Metrics (example)
- Reported by `src/evaluate.py`: Accuracy, Precision, Recall, F1, ROC AUC.

## Ethical Considerations
- Historical dataset includes socio-economic variables (e.g., `Pclass`) that can proxy protected attributes. This project is for learning; avoid real-world deployment decisions with such features without bias assessment.

## Limitations
- Small dataset; performance ceiling.
- Assumes independent samples and linear log-odds relation.
