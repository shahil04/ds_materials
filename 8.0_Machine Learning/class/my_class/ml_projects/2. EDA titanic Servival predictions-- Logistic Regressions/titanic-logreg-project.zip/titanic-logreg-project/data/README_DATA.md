# Data Folder

Put your Titanic CSV files here. Expected columns (Kaggle `train.csv`):

- Survived (target: 0/1)
- Pclass
- Name
- Sex
- Age
- SibSp
- Parch
- Ticket
- Fare
- Cabin
- Embarked

Notes:
- `Survived` is only in train.csv (for supervised learning).
- If you use a single `titanic.csv`, ensure it contains `Survived` for training.
