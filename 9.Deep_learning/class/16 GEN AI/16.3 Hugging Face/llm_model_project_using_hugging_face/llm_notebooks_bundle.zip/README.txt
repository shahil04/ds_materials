LLM Fine-tuning Notebooks

Files:
- 01_basic_usage.ipynb
- 02_finetune_llama_qlora.ipynb
- 03_finetune_gpt_openai.ipynb
- 04_finetune_t5.ipynb

Notes:
- Some cells have pip install commands commented out. Run them in a fresh environment or Colab.
- LLaMA weights may require special access and licensing.
- For OpenAI fine-tuning, set OPENAI_API_KEY in environment.
