# Math MCP Server

A beginner-friendly MCP server built with FastMCP.

## Setup

```bash
uv sync
```

## Run

```bash
uv run math-mcp
```

Or:

```bash
uv run python src/math_mcp/server.py
```

## Tools

- add
- subtract
- multiply
- divide
- power
- square_root
- factorial
- percentage
- average
- maximum
- minimum

## MCP Concepts

This project demonstrates:
- MCP Tools
- MCP Resources
- MCP Prompts
- FastMCP
- Python type hints
- Error handling
