from fastmcp import FastMCP
import math

mcp = FastMCP("Math Server")


@mcp.tool
def add(a: float, b: float) -> float:
    """Add two numbers."""
    return a + b


@mcp.tool
def subtract(a: float, b: float) -> float:
    """Subtract b from a."""
    return a - b


@mcp.tool
def multiply(a: float, b: float) -> float:
    """Multiply two numbers."""
    return a * b


@mcp.tool
def divide(a: float, b: float) -> float:
    """Divide a by b."""
    if b == 0:
        raise ValueError("Cannot divide by zero.")
    return a / b


@mcp.tool
def power(base: float, exponent: float) -> float:
    """Calculate base raised to exponent."""
    return base ** exponent


@mcp.tool
def square_root(number: float) -> float:
    """Calculate the square root of a number."""
    if number < 0:
        raise ValueError("Square root of a negative number is not supported.")
    return math.sqrt(number)


@mcp.tool
def factorial(number: int) -> int:
    """Calculate factorial of a non-negative integer."""
    if number < 0:
        raise ValueError("Factorial is not defined for negative numbers.")
    return math.factorial(number)


@mcp.tool
def percentage(value: float, percent: float) -> float:
    """Calculate a percentage of a value."""
    return value * percent / 100


@mcp.tool
def average(numbers: list[float]) -> float:
    """Calculate the average of a list of numbers."""
    if not numbers:
        raise ValueError("The list cannot be empty.")
    return sum(numbers) / len(numbers)


@mcp.tool
def maximum(numbers: list[float]) -> float:
    """Find the maximum number in a list."""
    if not numbers:
        raise ValueError("The list cannot be empty.")
    return max(numbers)


@mcp.tool
def minimum(numbers: list[float]) -> float:
    """Find the minimum number in a list."""
    if not numbers:
        raise ValueError("The list cannot be empty.")
    return min(numbers)


@mcp.resource("math://formulas")
def math_formulas() -> str:
    """Return common mathematical formulas."""
    return """
Common Mathematical Formulas

Addition:
a + b

Percentage:
percentage = value × percent / 100

Average:
average = sum(values) / number_of_values

Pythagorean Theorem:
a² + b² = c²

Circle Area:
A = πr²

Circle Circumference:
C = 2πr
"""


@mcp.prompt
def solve_math_problem(problem: str) -> str:
    """Create a prompt for solving a math problem."""
    return f"""
You are a mathematics tutor.

Solve the following problem:

{problem}

Requirements:
1. Explain the problem.
2. Identify the required formula.
3. Solve step by step.
4. Show the calculation.
5. Provide the final answer.
"""


def main():
    mcp.run()


if __name__ == "__main__":
    main()
