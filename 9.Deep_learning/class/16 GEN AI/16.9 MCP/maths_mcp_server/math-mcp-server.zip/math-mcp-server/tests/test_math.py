from src.math_mcp.server import (
    add,
    subtract,
    multiply,
    divide,
    power,
    square_root,
    factorial,
    percentage,
    average,
    maximum,
    minimum,
)


def test_add():
    assert add(10, 5) == 15


def test_subtract():
    assert subtract(10, 5) == 5


def test_multiply():
    assert multiply(10, 5) == 50


def test_divide():
    assert divide(10, 5) == 2


def test_power():
    assert power(2, 3) == 8


def test_square_root():
    assert square_root(25) == 5


def test_factorial():
    assert factorial(5) == 120


def test_percentage():
    assert percentage(200, 10) == 20


def test_average():
    assert average([10, 20, 30]) == 20


def test_maximum():
    assert maximum([10, 20, 30]) == 30


def test_minimum():
    assert minimum([10, 20, 30]) == 10
