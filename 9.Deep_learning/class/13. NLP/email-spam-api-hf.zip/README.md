# Email Spam Detection API (FastAPI)

This is a FastAPI-based ML API for classifying emails as Spam or Ham, deployed on Hugging Face Spaces using Docker.

## Endpoints

- `GET /` → Health check
- `POST /predict` → Takes `{ "email": "some text" }` and returns spam prediction.

## Example Request

```bash
curl -X POST https://your-space-url/predict \
     -H "Content-Type: application/json" \
     -d '{"email": "You won a free iPhone!"}'
```
