from fastapi import FastAPI
from pydantic import BaseModel
import numpy as np
import pickle
from tensorflow.keras.models import load_model

app = FastAPI()

model = load_model('app/ann_spam_model.h5')
with open('app/tfidf_vectorizer.pkl', 'rb') as f:
    tfidf = pickle.load(f)

class EmailRequest(BaseModel):
    email: str

@app.get("/")
def root():
    return {"message": "Email Spam Detection API is running!"}

@app.post("/predict")
def predict_email(data: EmailRequest):
    email_text = data.email
    email_vector = tfidf.transform([email_text]).toarray()
    prediction = model.predict(email_vector)

    label = "Spam" if prediction[0][0] >= 0.5 else "Ham"
    confidence = float(prediction[0][0]) if label == "Spam" else float(1 - prediction[0][0])

    return {
        "prediction": label,
        "confidence": round(confidence, 4)
    }
