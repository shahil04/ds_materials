# Hugging Face Streamlit App (Light Version)

Run:
```
pip install -r requirements.txt
streamlit run app.py
```

This version includes:
- Sentiment Analysis
- Text Generation
- Summarization
- Translation
- Zero-shot Classification
- Image Classification
- ASR (Speech-to-Text)
- Embeddings
