
import streamlit as st
from transformers import pipeline
from PIL import Image
import tempfile
import os

st.set_page_config(page_title="Hugging Face Multi-Model Demo", layout="wide")
st.title("🤗 Hugging Face Multi-Model Playground (Streamlit)")

st.sidebar.header("⚙️ Settings")
task = st.sidebar.selectbox(
    "Choose a task",
    [
        "Sentiment Analysis",
        "Text Classification",
        "Text Generation",
        "Summarization",
        "Translation EN→HI",
        "Zero-shot Classification",
        "Image Classification",
        "Speech to Text",
        "Feature Extraction (Embeddings)",
    ],
)

@st.cache_resource
def get_sentiment_pipe():
    return pipeline("sentiment-analysis")

@st.cache_resource
def get_text_cls_pipe():
    return pipeline("text-classification", model="distilbert-base-uncased")

@st.cache_resource
def get_text_gen_pipe():
    return pipeline("text-generation", model="gpt2")

@st.cache_resource
def get_summarization_pipe():
    return pipeline("summarization", model="facebook/bart-large-cnn")

@st.cache_resource
def get_translation_pipe():
    return pipeline("translation_en_to_hi", model="Helsinki-NLP/opus-mt-en-hi")

@st.cache_resource
def get_zero_shot_pipe():
    return pipeline("zero-shot-classification", model="facebook/bart-large-mnli")

@st.cache_resource
def get_image_cls_pipe():
    return pipeline("image-classification", model="google/vit-base-patch16-224")

@st.cache_resource
def get_asr_pipe():
    return pipeline("automatic-speech-recognition", model="openai/whisper-small")

@st.cache_resource
def get_embedding_pipe():
    return pipeline(
        "feature-extraction",
        model="sentence-transformers/all-MiniLM-L6-v2"
    )

if task == "Sentiment Analysis":
    text = st.text_area("Enter text", "I love using Hugging Face with Streamlit!")
    if st.button("Analyze"):
        st.json(get_sentiment_pipe()(text))

elif task == "Text Classification":
    text = st.text_area("Enter text", "This is amazing!")
    if st.button("Classify"):
        st.json(get_text_cls_pipe()(text))

elif task == "Text Generation":
    prompt = st.text_area("Prompt", "Once upon a time")
    if st.button("Generate"):
        st.write(get_text_gen_pipe()(prompt, max_length=50)[0]["generated_text"])

elif task == "Summarization":
    text = st.text_area("Text to summarize")
    if st.button("Summarize"):
        st.write(get_summarization_pipe()(text)[0]["summary_text"])

elif task == "Translation EN→HI":
    text = st.text_area("English text")
    if st.button("Translate"):
        st.write(get_translation_pipe()(text)[0]["translation_text"])

elif task == "Zero-shot Classification":
    text = st.text_area("Enter text")
    labels = st.text_input("Labels (comma-separated)", "education, sports, politics")
    if st.button("Classify"):
        st.json(get_zero_shot_pipe()(text, labels.split(",")))

elif task == "Image Classification":
    uploaded = st.file_uploader("Upload Image", type=["jpg","png","jpeg"])
    if uploaded:
        img = Image.open(uploaded).convert("RGB")
        st.image(img)
        if st.button("Classify"):
            st.json(get_image_cls_pipe()(img))

elif task == "Speech to Text":
    uploaded = st.file_uploader("Upload Audio", type=["wav","mp3"])
    if uploaded:
        with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as tmp:
            tmp.write(uploaded.read())
            temp_path = tmp.name
        st.write(get_asr_pipe()(temp_path)["text"])
        os.remove(temp_path)

elif task == "Feature Extraction (Embeddings)":
    text = st.text_area("Enter text")
    if st.button("Get Embeddings"):
        emb = get_embedding_pipe()(text)
        st.write(f"Embedding size: {len(emb[0][0])}")
