# Face Recognition Project

Instructions to run the project.