# Streamlit app with webcam and image upload
