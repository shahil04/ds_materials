# Script to train CNN on collected face images
