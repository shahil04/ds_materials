# Script to collect face images
