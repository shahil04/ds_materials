
import cv2
import mediapipe as mp
from math import hypot
import numpy as np
from ctypes import cast, POINTER
from comtypes import CLSCTX_ALL
from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
import streamlit as st
import subprocess

def run_volume_control():
    st.header("Volume Control with Hand Gestures")
    st.write("Click the button below to start the OpenCV window for hand gesture-based volume control.")
    
    if st.button("Start Volume Control"):
        subprocess.run(["python", "utilities/volume_control_script.py"])
