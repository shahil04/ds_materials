
import streamlit as st
import speech_recognition as sr

def run_stt():
    st.header("Speech-to-Text")
    if st.button("Start Recording"):
        recognizer = sr.Recognizer()
        with sr.Microphone() as source:
            st.info("Listening... Please speak")
            audio = recognizer.listen(source)
        try:
            text = recognizer.recognize_google(audio)
            st.success(f"Recognized Text: {text}")
        except Exception as e:
            st.error(f"Error: {e}")
