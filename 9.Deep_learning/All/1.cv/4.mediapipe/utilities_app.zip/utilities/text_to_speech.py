
import streamlit as st
import pyttsx3

def run_tts():
    st.header("Text-to-Speech")
    text = st.text_area("Enter text to convert to speech")
    if st.button("Convert to Speech"):
        engine = pyttsx3.init()
        engine.say(text)
        engine.runAndWait()
        st.success("Speech played successfully!")
