
import streamlit as st
from utilities.calculator import run_calculator
from utilities.text_to_speech import run_tts
from utilities.speech_to_text import run_stt
from utilities.volume_control import run_volume_control

st.title("Utilities App")
option = st.sidebar.selectbox("Choose a Utility", ["Calculator", "Text-to-Speech", "Speech-to-Text", "Volume Control"])

if option == "Calculator":
    run_calculator()
elif option == "Text-to-Speech":
    run_tts()
elif option == "Speech-to-Text":
    run_stt()
elif option == "Volume Control":
    run_volume_control()
