from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
from sentence_transformers import SentenceTransformer

def main():
    print("Downloading FLAN-T5 small...")
    AutoTokenizer.from_pretrained("google/flan-t5-small")
    AutoModelForSeq2SeqLM.from_pretrained("google/flan-t5-small")
    print("Downloading MiniLM embeddings...")
    SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")

if __name__ == "__main__":
    main()
