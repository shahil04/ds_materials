#!/usr/bin/env bash
set -e
uvicorn backend.main:app --reload --port 8000 &
streamlit run frontend/app.py
