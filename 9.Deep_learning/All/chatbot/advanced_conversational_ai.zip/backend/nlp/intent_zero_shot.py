from transformers import pipeline

class ZeroShotIntent:
    def __init__(self):
        self.clf = pipeline("zero-shot-classification", model="facebook/bart-large-mnli")
        self.labels = [
            "book_table", "cancel_reservation", "greeting", "goodbye",
            "menu_query", "restaurant_info", "opening_hours", "thanks", "fallback"
        ]

    def predict(self, text: str):
        out = self.clf(text, self.labels, multi_label=False)
        return out["labels"][0], float(out["scores"][0])
