import spacy

try:
    nlp = spacy.load("en_core_web_sm")
except OSError:
    nlp = None  # Model not present; handle gracefully

def extract_entities(text: str):
    if nlp is None:
        return {"error": "spaCy model en_core_web_sm not installed. Run: python -m spacy download en_core_web_sm"}
    doc = nlp(text)
    ents = [{"text": e.text, "label": e.label_} for e in doc.ents]
    return {"entities": ents}
