import numpy as np
import faiss
from sentence_transformers import SentenceTransformer
import yaml

class RAGRetriever:
    def __init__(self, config_path: str = "config.yaml"):
        with open(config_path) as f:
            cfg = yaml.safe_load(f)
        self.index_path = cfg["rag"]["index_path"]
        self.store_path = cfg["rag"]["store_path"]
        self.top_k = cfg["rag"]["top_k"]
        self.embedder = SentenceTransformer(cfg["embedder"]["model_name"])
        self.index = faiss.read_index(self.index_path)
        self.corpus = np.load(self.store_path, allow_pickle=True)

    def search(self, query: str, top_k: int | None = None):
        k = top_k or self.top_k
        q = self.embedder.encode([query], convert_to_numpy=True, normalize_embeddings=True)
        scores, idxs = self.index.search(q, k)
        results = []
        for s, i in zip(scores[0], idxs[0]):
            results.append({"score": float(s), "text": str(self.corpus[i])})
        return results

    def format_context(self, results):
        return "\n\n".join([f"[Doc score={r['score']:.3f}]\n{r['text']}" for r in results])
