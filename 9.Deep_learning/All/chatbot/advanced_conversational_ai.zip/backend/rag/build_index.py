import os
import glob
import numpy as np
import faiss
from sentence_transformers import SentenceTransformer
import yaml

CONFIG_PATH = "config.yaml"

def load_config():
    with open(CONFIG_PATH) as f:
        return yaml.safe_load(f)

def read_corpus(path="data/sample_docs"):
    texts, meta = [], []
    for p in glob.glob(os.path.join(path, "*")):
        with open(p, "r", encoding="utf-8") as f:
            txt = f.read().strip()
        texts.append(txt)
        meta.append({"path": p})
    return texts, meta

def main():
    cfg = load_config()
    embedder_name = cfg["embedder"]["model_name"]
    index_path = cfg["rag"]["index_path"]
    store_path = cfg["rag"]["store_path"]

    os.makedirs(os.path.dirname(index_path), exist_ok=True)

    model = SentenceTransformer(embedder_name)
    texts, meta = read_corpus()

    embeddings = model.encode(texts, convert_to_numpy=True, normalize_embeddings=True)
    dim = embeddings.shape[1]
    index = faiss.IndexFlatIP(dim)
    index.add(embeddings)

    faiss.write_index(index, index_path)
    np.save(store_path, np.array(texts, dtype=object))

    print(f"Built index with {len(texts)} docs -> {index_path}")

if __name__ == "__main__":
    main()
