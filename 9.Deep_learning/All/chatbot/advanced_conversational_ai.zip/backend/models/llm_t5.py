from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
from typing import List, Dict

class T5Chat:
    def __init__(self, model_name: str = "google/flan-t5-small", max_new_tokens: int = 256, temperature: float = 0.3):
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForSeq2SeqLM.from_pretrained(model_name)
        self.max_new_tokens = max_new_tokens
        self.temperature = temperature

    def build_prompt(self, history: List[Dict[str,str]], user: str, context: str | None = None) -> str:
        sys = "You are a helpful, concise restaurant assistant. Use provided context if relevant."
        conv = []
        if context:
            conv.append(f"[Context]\n{context}\n[/Context]")
        for turn in history[-6:]:  # last 6 messages to limit prompt
            conv.append(f"{turn['role'].capitalize()}: {turn['content']}")
        conv.append(f"User: {user}")
        conv.append("Assistant:")
        return sys + "\n\n" + "\n".join(conv)

    def generate(self, prompt: str) -> str:
        inputs = self.tokenizer(prompt, return_tensors="pt")
        outputs = self.model.generate(
            **inputs,
            do_sample=True if self.temperature>0 else False,
            temperature=self.temperature,
            max_new_tokens=self.max_new_tokens
        )
        return self.tokenizer.decode(outputs[0], skip_special_tokens=True)
