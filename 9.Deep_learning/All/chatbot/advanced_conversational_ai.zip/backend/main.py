import os
import yaml
from fastapi import FastAPI
from pydantic import BaseModel
from typing import List, Dict, Optional

from backend.models.llm_t5 import T5Chat
from backend.rag.retriever import RAGRetriever
from backend.nlp.intent_zero_shot import ZeroShotIntent
from backend.nlp.ner_spacy import extract_entities

class ChatTurn(BaseModel):
    role: str
    content: str

class ChatRequest(BaseModel):
    message: str
    history: List[ChatTurn] = []
    use_rag: bool = True
    top_k: Optional[int] = None

class ChatResponse(BaseModel):
    reply: str
    intent: Optional[str] = None
    entities: Optional[Dict] = None
    context_snippets: Optional[List[str]] = None

app = FastAPI(title="Advanced Conversational AI")

with open("config.yaml") as f:
    cfg = yaml.safe_load(f)

llm = T5Chat(
    model_name=cfg["model"]["model_name"],
    max_new_tokens=cfg["model"]["max_new_tokens"],
    temperature=cfg["model"]["temperature"]
)

retriever = None
if cfg["rag"]["enabled"] and os.path.exists(cfg["rag"]["index_path"]):
    try:
        retriever = RAGRetriever("config.yaml")
    except Exception as e:
        retriever = None
        print("RAG init failed:", e)

intent_clf = ZeroShotIntent()

@app.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    # Intent + NER
    intent, intent_score = intent_clf.predict(req.message)
    ner = extract_entities(req.message)

    context = None
    ctx_snips = None
    if req.use_rag and retriever:
        results = retriever.search(req.message, top_k=req.top_k)
        ctx_snips = [r["text"] for r in results]
        context = retriever.format_context(results)

    prompt = llm.build_prompt(
        history=[t.model_dump() for t in req.history],
        user=req.message,
        context=context
    )
    reply = llm.generate(prompt)
    return ChatResponse(reply=reply, intent=intent, entities=ner, context_snippets=ctx_snips)

@app.post("/intent")
def classify_intent(payload: Dict[str, str]):
    text = payload.get("text", "")
    intent, score = intent_clf.predict(text)
    return {"intent": intent, "score": score}

@app.post("/ner")
def ner_endpoint(payload: Dict[str, str]):
    text = payload.get("text", "")
    return extract_entities(text)
