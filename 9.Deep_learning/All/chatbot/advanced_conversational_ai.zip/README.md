# Advanced Conversational AI — Modular Chatbot Stack

This project gives you a **production-style skeleton** for building advanced chatbots using:
- **Transformer-based chat** (default: `google/flan-t5-small` for CPU-friendly generation)
- **Encoder–Decoder architecture** (T5-based pipeline)
- **RAG (Retrieval-Augmented Generation)** with FAISS + Sentence-Transformers
- **Optional NER** (spaCy) and **Zero-shot Intent** (BART MNLI)
- **FastAPI backend** + **Streamlit UI** + **Docker**

> Swap in larger models (T5-base, Mistral, LLaMA) or provider APIs by editing `config.yaml` or `backend/models/*` adapters.

## Quickstart

```bash
# 1) Python env
python -m venv .venv && source .venv/bin/activate  # (Windows: .venv\Scripts\activate)
pip install -r requirements.txt

# 2) (Optional) download small models to cache for first run
python scripts/download_models.py

# 3) Build a RAG index from sample docs
python backend/rag/build_index.py

# 4) Run backend
uvicorn backend.main:app --reload --port 8000

# 5) Run Streamlit UI
streamlit run frontend/app.py
```

Open UI: http://localhost:8501  (Backend: http://localhost:8000)

## Features
- **Chat** endpoint `/chat` with:
  - Model selection (`t5-small` by default; configure in `config.yaml`)
  - Optional **RAG** (`top_k`, `use_rag` flags)
  - **Context windowing** from chat history
- **RAG** with FAISS index and MiniLM embeddings
- **Zero-shot Intent** (`/intent`) with `facebook/bart-large-mnli`
- **NER** (`/ner`) via spaCy (en_core_web_sm)
- **Dockerfile** for containerization

## Switch Models
- HF local: set `model_name` in `config.yaml` (e.g., `google/flan-t5-base`).
- API providers (OpenAI/Mistral/Together): add keys via env and use adapters in `backend/models/`.

## Notes
- Default stack is **CPU-friendly**. Larger models may need GPU.
- Sample docs for RAG live in `data/sample_docs/`.
