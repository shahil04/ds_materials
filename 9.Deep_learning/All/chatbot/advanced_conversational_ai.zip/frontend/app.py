import streamlit as st
import requests
import os

st.set_page_config(page_title="Advanced Conversational AI", page_icon="🤖", layout="wide")

BACKEND = os.getenv("BACKEND_URL", "http://localhost:8000")

st.title("🤖 Advanced Conversational AI — RAG + T5")
st.caption("Transformer chat • Encoder–Decoder • Zero-shot intent • spaCy NER • FAISS RAG")

col1, col2 = st.columns([2,1])
with col2:
    use_rag = st.toggle("Use RAG", value=True)
    top_k = st.number_input("Top K docs", 1, 10, 3)

with col1:
    if "history" not in st.session_state:
        st.session_state.history = []

    user_msg = st.chat_input("Type your message...")
    if user_msg:
        payload = {
            "message": user_msg,
            "history": [{"role": r, "content": c} for r, c in st.session_state.history],
            "use_rag": use_rag,
            "top_k": int(top_k)
        }
        try:
            r = requests.post(f"{BACKEND}/chat", json=payload, timeout=60)
            data = r.json()
            st.session_state.history.append(("user", user_msg))
            st.session_state.history.append(("assistant", data.get("reply","")))
            st.session_state.last_meta = data
        except Exception as e:
            st.error(f"Backend error: {e}")

for role, content in st.session_state.get("history", []):
    if role == "user":
        st.chat_message("user").markdown(content)
    else:
        st.chat_message("assistant").markdown(content)

meta = st.session_state.get("last_meta")
if meta:
    with st.expander("🔎 Intent & Entities & Context"):
        st.write("**Intent:**", meta.get("intent"))
        ents = meta.get("entities", {})
        if isinstance(ents, dict) and "entities" in ents:
            st.write("**Entities:**", ents["entities"])
        else:
            st.write("**Entities:**", ents)
        ctx = meta.get("context_snippets") or []
        if ctx:
            st.write("**Top docs:**")
            for i, c in enumerate(ctx,1):
                st.write(f"**{i}.**", c[:500] + ("..." if len(c)>500 else ""))
