from fastapi import FastAPI, Request
from pydantic import BaseModel
import numpy as np
import pickle
from tensorflow.keras.models import load_model
from sklearn.feature_extraction.text import TfidfVectorizer

app = FastAPI()

# Load model and vectorizer
model = load_model('ann_spam_model.h5')
with open('tfidf_vectorizer.pkl', 'rb') as f:
    tfidf = pickle.load(f)

class EmailRequest(BaseModel):
    email: str

@app.get("/")
def read_root():
    return {"message": "Email Spam Detection API is running!"}

@app.post("/predict")
def predict_spam(data: EmailRequest):
    email_text = data.email
    email_vector = tfidf.transform([email_text]).toarray()
    prediction = model.predict(email_vector)
    label = "Spam" if prediction[0][0] >= 0.5 else "Ham"
    confidence = float(prediction[0][0]) if label == "Spam" else float(1 - prediction[0][0])
    return {"prediction": label, "confidence": round(confidence, 4)}
