
# config.py - update with your MySQL credentials
DB_CONFIG = {
    "host": "localhost",
    "port": 3306,
    "user": "root",
    "password": "your_mysql_password",
    "database": "cs_with_shahil_db"
}
