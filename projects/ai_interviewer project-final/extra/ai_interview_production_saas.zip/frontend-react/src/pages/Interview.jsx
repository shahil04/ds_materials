
import { useEffect, useState } from "react";
import api from "../services/api";

export default function Interview() {
  const [question, setQuestion] = useState("");

  const next = async () => {
    const res = await api.get("/interview/next");
    setQuestion(res.data.done ? "Interview Completed" : res.data.text);
  };

  useEffect(() => { next(); }, []);

  return (
    <div>
      <h2>Interview</h2>
      <p>{question}</p>
      <button onClick={next}>Next</button>
    </div>
  );
}
