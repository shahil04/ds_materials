
# Enterprise AI Interview SaaS

## Features
- Authentication (JWT ready)
- Interview Engine (AI pluggable)
- Automated Grading
- Admin Dashboard
- Dockerized Deployment

Run:
docker-compose up --build
