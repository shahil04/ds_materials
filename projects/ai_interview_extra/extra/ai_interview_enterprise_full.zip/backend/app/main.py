
from fastapi import FastAPI
from app.database import Base, engine
from app.routes import interview, dashboard

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Enterprise AI Interview SaaS")

app.include_router(interview.router, prefix="/api/interview")
app.include_router(dashboard.router, prefix="/api/dashboard")
