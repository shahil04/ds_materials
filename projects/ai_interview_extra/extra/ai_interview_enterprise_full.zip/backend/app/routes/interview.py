
from fastapi import APIRouter
from app.models import Interview
from app.database import SessionLocal

router = APIRouter()

QUESTIONS = [
 "Introduce yourself",
 "Explain your last project",
 "Explain Python decorators",
 "Explain SQL joins",
 "Explain REST API",
 "Explain Docker",
 "Explain system design",
 "Any questions for us?"
]

@index = 0

@router.get("/next")
def next_question():
    global index
    if index >= len(QUESTIONS):
        return {"done": True}
    q = QUESTIONS[index]
    index += 1
    return {"text": q, "audio": ""}

@router.post("/answer")
def save_answer(question: str, answer: str, silence: bool=False):
    db = SessionLocal()
    db.add(Interview(question=question, answer=answer, silence=silence))
    db.commit()
    return {"saved": True}
