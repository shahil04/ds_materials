# DB config for the demo
DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "root",
    "database": "lms_db"
}
