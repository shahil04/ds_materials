import streamlit as st
st.title("Uber-like Demo")
st.write("🚗 Welcome to the Uber Streamlit + MySQL Simulation!")
st.write("Use tabs for Riders, Drivers, and Admin actions.")
