-- Identifying high-value customers who have account balances above ₹40,000 and have taken a loan above ₹500,000.

SELECT c.CustomerID, c.FirstName, c.LastName, a.Balance, l.LoanAmount
FROM Customers c
JOIN Accounts a ON c.CustomerID = a.CustomerID
JOIN Loans l ON c.CustomerID = l.CustomerID
WHERE a.Balance > 40000 AND l.LoanAmount > 500000;

-- Customers who have made atleast more than once debit or credit transaction in January 2024.

SELECT c.CustomerID, c.FirstName, c.LastName,
		COUNT(t.TransactionID) AS DebitCount
FROM Customers c
JOIN Accounts a ON c.CustomerID = a.CustomerID
JOIN Transactions t ON a.AccountID = t.AccountID
WHERE t.TransactionType IN ('Credit', 'Debit') 
		AND MONTH(t.TransactionDate) = 1 
		AND YEAR(t.TransactionDate) = 2024
GROUP BY c.CustomerID, c.FirstName, c.LastName
HAVING COUNT(t.TransactionID) > 1;

-- Ranking Customers based on total credited amount per customer

SELECT c.CustomerID, c.FirstName, c.LastName, 
    SUM(t.Amount) AS TotalCredit,
    RANK() OVER (ORDER BY SUM(t.Amount) DESC) AS CreditRank
FROM Customers c
JOIN Accounts a ON c.CustomerID = a.CustomerID
JOIN Transactions t ON a.AccountID = t.AccountID
WHERE t.TransactionType = 'Credit'
GROUP BY c.CustomerID, c.FirstName, c.LastName limit 5;

-- Average loan amount by loan type and display types with average loan > ₹400,000

SELECT LoanType, AVG(LoanAmount) AS AvgLoanAmount
FROM Loans
GROUP BY LoanType
HAVING AVG(LoanAmount) > 400000;

-- Customers who have inactive accounts but have active loans

SELECT c.CustomerID, c.FirstName, c.LastName,
	   a.Status AS AccountStatus, l.Status AS LoanStatus
FROM Customers c
JOIN Accounts a ON c.CustomerID = a.CustomerID
JOIN Loans l ON c.CustomerID = l.CustomerID
WHERE a.Status = 'Inactive' AND l.Status = 'Active';

-- Monthly-wise total debit and credit transaction amounts for each customer for the year 2024.

SELECT c.CustomerID, c.FirstName, c.LastName, MONTH(t.TransactionDate) AS TxnMonth,
    SUM(CASE WHEN t.TransactionType = 'Debit' THEN t.Amount ELSE 0 END) AS TotalDebit,
    SUM(CASE WHEN t.TransactionType = 'Credit' THEN t.Amount ELSE 0 END) AS TotalCredit
FROM Customers c
JOIN Accounts a ON c.CustomerID = a.CustomerID
JOIN Transactions t ON a.AccountID = t.AccountID
WHERE YEAR(t.TransactionDate) = 2024
GROUP BY c.CustomerID, c.FirstName, c.LastName, MONTH(t.TransactionDate)
ORDER BY c.CustomerID, TxnMonth;

-- Customers who have not taken any loans but have made at least 2 transactions in 2024.

SELECT c.CustomerID, c.FirstName, c.LastName, 
	   COUNT(t.TransactionID) AS TxnCount
FROM Customers c
JOIN Accounts a ON c.CustomerID = a.CustomerID
JOIN Transactions t ON a.AccountID = t.AccountID
WHERE YEAR(t.TransactionDate) = 2024
AND NOT EXISTS (SELECT 1 FROM Loans l 
	WHERE l.CustomerID = c.CustomerID)
GROUP BY c.CustomerID, c.FirstName, c.LastName
HAVING COUNT(t.TransactionID) >= 2;

-- ================================== USER-DEFINED FUNCTION =====================================
-- Age Category Function - categorize in young, middle-aged and senior

DELIMITER //

CREATE FUNCTION GetAgeCategory(DOB DATE)
RETURNS VARCHAR(20)
DETERMINISTIC
BEGIN
    DECLARE Age INT;
    SET Age = TIMESTAMPDIFF(YEAR, DOB, CURDATE());

    RETURN (
        CASE 
            WHEN Age < 40 THEN 'Young'
            WHEN Age BETWEEN 40 AND 50 THEN 'Middle-aged'
            ELSE 'Senior'
        END
    );
END //

DELIMITER ;

-- Listing customers along with their age category using GetAgeCategory function

SELECT 
    CustomerID,
    FirstName,
    LastName,
    DOB,
    GetAgeCategory(DOB) AS AgeCategory
FROM Customers;

-- function to segregate customers in premium, standard and deluxe

DELIMITER //
CREATE FUNCTION GetAccountCategory(balance DECIMAL(15,2))
RETURNS VARCHAR(20)
DETERMINISTIC
BEGIN
    DECLARE category VARCHAR(20);
    IF balance >= 90000 THEN
        SET category = 'Premium';
    ELSEIF balance >= 70000 THEN
        SET category = 'Deluxe';
    ELSE
        SET category = 'Standard';
    END IF;
    RETURN category;
END //
DELIMITER ;

-- get account category of customers

SELECT c.CustomerID, FirstName, LastName, Balance,
    GetAccountCategory(Balance) AS AccountCategory
FROM Customers c
JOIN Accounts a ON c.CustomerID = a.CustomerID;

-- ============================= VIEW =============================================================
-- A view of active customers with total account bacustomerportfoliosummarylance and total loan amount as a financial portfolio summary.

CREATE OR REPLACE VIEW CustomerPortfolioSummary AS
SELECT c.CustomerID, c.FirstName, c.LastName,
    SUM(a.Balance) AS TotalBalance,
    SUM(l.LoanAmount) AS TotalLoan
FROM Customers c
JOIN Accounts a ON c.CustomerID = a.CustomerID
LEFT JOIN Loans l ON c.CustomerID = l.CustomerID
WHERE c.Status = 'Active'
GROUP BY c.CustomerID, c.FirstName, c.LastName;

select * from CustomerPortfolioSummary;

-- ===================================== STORED PROCEDURE =========================================
-- Creating a stored procedure to update customer status to 'Inactive' if they have no transactions in the last 12 months.

DELIMITER //
CREATE PROCEDURE DeactivateDormantCustomers()
BEGIN
    UPDATE Customers
    SET Status = 'Inactive'
    WHERE CustomerID NOT IN (
        SELECT DISTINCT c.CustomerID
        FROM Customers c
        JOIN Accounts a ON c.CustomerID = a.CustomerID
        JOIN Transactions t ON a.AccountID = t.AccountID
        WHERE t.TransactionDate >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
    );
END //
DELIMITER ;

call DeactivateDormantCustomers();
