# 📄 SDFC Bank Customer Analytics Project

## 💡 Overview

This project analyzes customer data for **SDFC Bank**, a leading private sector bank in India. The main objective is to deliver actionable insights into customer segmentation, transaction behavior, and loan exposures using advanced SQL queries.

---

## 🏦 Problem Statement

SDFC Bank faces several challenges:
- Identifying and retaining high-value customers
- Managing inactive accounts and monitoring loan risks
- Improving cross-selling opportunities
- Automating customer status management

---

## 🗂️ Database Schema

The project uses a relational schema with the following main tables:
- **Customers**: Customer details and demographics
- **Accounts**: Account balances and statuses
- **Transactions**: Debit and credit activity with dates
- **Loans**: Loan types, amounts, and statuses

> 📄 *Refer to the included schema diagram image for a visual overview.*

---

## 🔍 Key SQL Analyses & Features

### 💎 High-Value Customer Identification
Identifies customers with account balances above ₹40,000 and loans above ₹500,000 to focus on premium segments.

### 🔥 Active Transaction Customers (Jan 2024)
Selects customers with more than one debit or credit transaction in January 2024, indicating high engagement.

### 🥇 Customer Ranking by Credit Amount
Ranks customers based on total credited amounts using SQL window functions.

### 💰 Average Loan Analysis
Displays average loan amounts by type and filters types with averages above ₹400,000.

### ⚠️ Inactive Accounts with Active Loans
Detects customers whose accounts are inactive but loans remain active, highlighting potential risk areas.

### 📊 Monthly Transaction Summary (2024)
Summarizes monthly debit and credit totals per customer throughout 2024.

### 🧐 Active Non-Loan Customers
Identifies customers who have made at least two transactions in 2024 but have no loans — potential targets for cross-selling.

### 👤 Customer Segmentation Functions
- **Age Category Function**: Categorizes customers as Young (<30), Middle-aged (30–55), or Senior (>55).
- **Segment Function**: Segregates customers as Premium, Standard, or Deluxe based on balances.

### 💼 Financial Portfolio View
Combines account balances and loan amounts to create a comprehensive financial snapshot per active customer.

### 🔄 Automated Inactive Status Procedure
Stored procedure to update a customer's status to 'Inactive' if no transactions occur in the last 12 months.

---

## 🖼️ Presentation

A detailed presentation summarizing the queries, analysis logic, and business context is available:

- 🌟 [**View Presentation**] Attached in this Repository

---

## ⚙️ Technologies Used

- **SQL** (MySQL syntax)
- ERD & schema design
- Data segmentation and analytics
- Visual presentation tools

---

## 🤝 Contributing

Contributions are welcome! You can open issues or submit pull requests to improve queries, add visualizations, or enhance analyses.

---

## 📧 Contact

For questions or feedback, please create an issue or reach out via email.

---

### ⭐ *Thank you for exploring this project!*
