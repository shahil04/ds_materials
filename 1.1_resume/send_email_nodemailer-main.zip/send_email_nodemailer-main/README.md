install node modules
use google less secuere for third party username password for nodemailer
watch the youtube video carefully
Happy Hacking!
Follow me :)
