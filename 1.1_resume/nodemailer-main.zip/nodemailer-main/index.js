

// let content =
// document.querySelector('body').innerHTML;
// const emailPattern = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,7}/g;
// const emailAddresses = content.match(emailPattern) || [];
// let unique = new Set(emailAddresses);
// let email = [...unique];
// console.log(email);


const http = require("http");
const nodemailer = require("nodemailer");

const server = http.createServer((request, response) => {
    const auth = nodemailer.createTransport({
        service: "gmail",
        secure: true,
        port: 465,
        auth: {
            user: "mohammadshahil4u@gmail.com",
            pass: "frim jsfm nwwu lhyj"
        }
    });
    

 
const recipients = [
    "vinoth.r@saksoft.com",
    "Awanish.pal@innovasolutions.com",
    "pranshu.sharma@rblbank.com",
    "anjely@innovatz.com.my",
    "CV-regita.dn@finansia.com",
    "veena.verma@snowrelic.com",
    "gerlie@theexecutiveprofile.com",
    "pratikconvictionglobal@gmail.com",
    "priyanka.sikarwar@igreendata.com.au",
    "sujam@canvendor.com",
    "ashish.bajaj30@gmail.com",
    "indusconsultings@gmail.com",
    "indushr@indusitc.com",
    "neha.trivedi@s3bglobal.com",
    "nithya.g@vibotek.com",
    "recruitment@julo.co.id",
    "dkumar@sensenrespond.com",
    "alvionita.aulia@accordinnovations.com",
    "kushal.jaiswal@ustechsolutionsinc.com",
    "careers@tekrowe.com",
    "Shaloo@apptadinc.com",
    "hrdcrutzleela@gmail.com",
    "sharmilabanu.r@vdartinc.com",
    "sushma@metamorfs.com",
    "keerthi@sun-itsolutions.com",
    "neeraj.ch@ritefit.ai",
    "srinithi@vysystems.com",
    "devashishs2108@gmail.com",
    "radheyshyam.srivastava@mobikwik.com",
    "bhavanikrishna8008@gmail.com",
    "pgoyal@krconsultant.com",
    "sayanti.s@shenzyn.com",
    "anwesha.ray@techilaservices.com",
    "praveen@evolveesolutions.com",
    "careers@gigaswartechnologies.com",
    "pujitha@sun-itsolutions.com",
    "jobs@thehiringpartner.com",
    "sudhir@haulplus.in",
    "steve@evolveesolutions.com",
    "hr@zuaitech.org",
    "Nandini@evolveesolutions.com",
    "jobs@kripsontech.co.uk",
    "Shubhamshukla@sierraconsult.com",
    "era.joshi@bizquad.co.in",
    "Gunjan@evolveesolutions.com",
    "Varun@TalentVidas.com",
    "careers@tirabeauty.com",
    "manishas@ridikgrad.com",
    "hr@trbitix.com",
    "elangkannan.ks@hitachienergy.com",
    "nitish.kumar@materialplus.io",
    "nitish.kumar@giggslab.com",
    "Jobs@askexim.in",
    "Preeti@evolveesolutions.com",
    "kumar@Cloudious.com",
    "-suryasingh@indusitc.com",
    "suryasingh@indusitc.com",
    "radhika.m@costaffglobal.in",
    "radhika@prominentstaffing.in",
    "Recruitment@blackstraw.ai",
    "lakidi.krishna@gmail.com",
    "jinsha.vijayan@kaviglobal.com",
    "sateesh.yaragatti@xoin.eurofinsasia.com",
    "Siddharth.hardiya@talentlynk.in",
    "syed@technivio.net",
    "bhumi.tibrewal@apptadinc.com",
    "shweta.bansod@infoorigin.com",
    "krishnateja.k@careersoftusa.com",
    "payal.singh@recrivio.com",
    "hrritu474@gmail.com",
    "nilimaw1903@gmail.com",
    "marti@karwelltech.us",
    "recruitmentdrive_queries@allianz.com",
    "Zubair.saad@pentangletech.com",
    "ramya.k@fidelisgroup.in",
    "amala@adalitekgroup.com",
    "official@knaptix.in",
    "Vinod.b@itechus.net",
    "pradeep.rawat@envisiontechsol.com",
    "pedapati.harshasrinandinidevi@clyptus.com",
    "ashwini.k@peoplegamut.com",
    "gianna@dprsolutionsinc.com",
    "gowthami.k@msysinc.com",
    "shrasti.singh@anrisolutions.com",
    "Akanksha.mittal@chicmicstudios.in",
    "diksha@peoplegamut.com",
    "anil.k@maximatek.com",
    "anjana@silverpeople.in",
    "Thrinadh@purexcel.com",
    "Thrinadh@PureXcel.com",
    "anastasya.cahyani@peluangkerjaku.com",
    "alisha@luzontech.com",
    "sandeep.shetti@eateam.com",
    "ranadheesh.s@vipanyglobal.co"

    ];
    
    

    // Function to send emails to each recipient
    const sendEmailToRecipient = (recipientIndex) => {
        if (recipientIndex >= recipients.length) {
            console.log("All emails sent!");
            response.end();
            return;
        }

        const recipient = recipients[recipientIndex];
        if (!recipient) {
            console.log(`Invalid recipient at index ${recipientIndex}`);
            sendEmailToRecipient(recipientIndex + 1); // Skip invalid email
            return;
        }

        const receiver = {
            from: "mohammadshahil4u@gmail.com",
            to: recipient,
            subject: "Application for Data Science Position",
            text: `Dear Hiring Manager,
    
I am excited to apply for the Data Scientist position at your organization. With hands-on experience in Python, SQL, Power BI, Machine Learning, and tools like Pandas, scikit-learn, Flask, and Streamlit,
I have led several end-to-end data science projects and trained over 200 students in core analytics skills.

Please find my resume attached for your review.
I look forward to the opportunity to contribute to your data-driven team.

Thank you for your time and consideration.

Sincerely, 
MD Shahil Ansari
mohammadshahil4u@gmail.com | +91 9708549289
`,
            attachments: [
                {
                    filename: "Shahil_Resume.pdf", // Name of your PDF file in the project directory
                    path: "Shahil_Resume.pdf", // Directly use the file name if it's in the same directory
                    contentType: "application/pdf" // Content type for PDF
                }
            ]
        };

        auth.sendMail(receiver, (error, emailResponse) => {
            if (error) {
                console.error(`Error sending email to ${recipient}: ${error}`);
                throw error;
            }
            console.log(`Email sent to ${recipient}`);
            sendEmailToRecipient(recipientIndex + 1); // Move to the next recipient
        });
    };

    sendEmailToRecipient(0); // Start the loop from the first recipient
});

server.listen(8080);