from flask import Blueprint, render_template, request, redirect, url_for, flash
from .db import get_db_connection

todo_bp = Blueprint('todo', __name__)

@todo_bp.route('/')
def index():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute('SELECT * FROM todos')
    tasks = cursor.fetchall()
    cursor.close()
    conn.close()
    return render_template('index.html', tasks=tasks)

@todo_bp.route('/add', methods=['POST'])
def add_task():
    task = request.form.get('task')
    if not task.strip():
        flash("Task cannot be empty!", "error")
        return redirect(url_for('todo.index'))
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('INSERT INTO todos (task) VALUES (%s)', (task,))
    conn.commit()
    cursor.close()
    conn.close()
    flash("Task added successfully!", "success")
    return redirect(url_for('todo.index'))

@todo_bp.route('/update/<int:id>')
def update_task(id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('UPDATE todos SET status="Completed" WHERE id=%s', (id,))
    conn.commit()
    cursor.close()
    conn.close()
    flash("Task marked as completed!", "success")
    return redirect(url_for('todo.index'))

@todo_bp.route('/delete/<int:id>')
def delete_task(id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM todos WHERE id=%s', (id,))
    conn.commit()
    cursor.close()
    conn.close()
    flash("Task deleted successfully!", "success")
    return redirect(url_for('todo.index'))
